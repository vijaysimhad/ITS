/**
 * 
 */
package com.intuit.its.service.vo;

import java.io.Serializable;


/**
 * @author Vijayasimha Devulapalli
 *
 */
public class PlanetVO implements Serializable{
	
    private static final long serialVersionUID = -1769191232620245016L;
    
    private Integer planetId;
	
	private String planetName;
	
	private String planetNode;

	public Integer getPlanetId() {
		return planetId;
	}

	public void setPlanetId(Integer planetId) {
		this.planetId = planetId;
	}

	public String getPlanetName() {
		return planetName;
	}

	public void setPlanetName(String planetName) {
		this.planetName = planetName;
	}

	public String getPlanetNode() {
		return planetNode;
	}

	public void setPlanetNode(String planetNode) {
		this.planetNode = planetNode;
	}


	
	
	

}
