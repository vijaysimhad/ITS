package com.intuit.its.dto;

import java.io.Serializable;

public interface BaseDTO extends Serializable{

}
