package com.intuit.its.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ca.digital.constants.DigitalConstants;
import com.ca.digital.dao.BaseHibernateDAO;
import com.ca.digital.dao.PlanetDAO;
import com.ca.digital.entity.PlanetDTO;
import com.ca.digital.utility.CommonUtility;

@SuppressWarnings("rawtypes")
@Repository("planetDAO")
@Scope("prototype")
public class PlanetDAOImpl extends BaseHibernateDAO implements PlanetDAO{

	private static final Logger logger = Logger.getLogger(PlanetDAOImpl.class);
	
	@SuppressWarnings("unchecked")
	@PostConstruct
	public void setClassForDao(){
		setDAOClass(PlanetDAOImpl.class);
	}

	/**
	 * This Method is used to fetch all the planets
	 *  
	 */
	@Override
	public List<PlanetDTO> getAllPlanets(SessionFactory sessionFactory) {
		return getAll("PlanetDTO",sessionFactory);
	}

	/**
	 * This Method is used to create new planet and return planetId
	 *  
	 */
	@Override
	public Object createPlanet(PlanetDTO planetDTO,SessionFactory sessionFactory) {
		// TODO Auto-generated method stub
		logger.info(CommonUtility.getCurrentTimeStamp()+" :::  In Planet DAO IMPL for createPlanet ::: ");
		return create(planetDTO,sessionFactory);
	}
	
	/**
	 * This Method is used to update the planet
	 *  
	 */	
	@Override
	public void updatePlanet(Map<String, Object> queryValuesMap, SessionFactory sessionFactory) {
		// TODO Auto-generated method stub
		logger.info(CommonUtility.getCurrentTimeStamp()+" :::  In Planet DAO IMPL for updatePlanet ::: ");
		String queryString = "update PlanetDTO as plantDTO set plantDTO.planetName= :planetName, "
				+ "plantDTO.planetNode= :planetNode, plantDTO.distance= :distance, plantDTO.traffic= :traffic";
		updateEntityObjects(queryString, queryValuesMap, sessionFactory);
	}
	
	/**
	 * This Method is used to check if the planet exists or not based on emailId
	 *  
	 */
	@Override
	public Object findPlanet(PlanetDTO planetDTO, String planetNode, SessionFactory sessionFactory) {
		// TODO Auto-generated method stub
		logger.info(CommonUtility.getCurrentTimeStamp()+" :::  In Planet DAO IMPL for findPlanet ::: ");
		String strQuery1 = "from PlanetDTO as plantDTO where plantDTO.planetNode= :planetNode";
		return getByName(strQuery1, "planetNode",planetNode,sessionFactory);
	}

	/**
	 * This Method is used to check if the planet exists or not based on emailId
	 *  
	 */
	public Object findPlanetUsingId(PlanetDTO planetDTO, Integer planetId, SessionFactory sessionFactory) {
		// TODO Auto-generated method stub
		logger.info(CommonUtility.getCurrentTimeStamp()+" :::  In Planet DAO IMPL for findPlanetForAOP ::: ");
		String strQuery1 = "from PlanetDTO as plantDTO where plantDTO.planetId= :planetId";
		return getById(strQuery1, "planetId",planetId,sessionFactory);
	}


		
}
