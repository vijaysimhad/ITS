package com.intuit.its.service.vo;

public class EdgeVO {
	private final String id;
    private final PlanetVO source;
    private final PlanetVO destination;
    private final int distance;
    private final int traffic;

    public EdgeVO(String id, PlanetVO source, PlanetVO destination, int traffic, int distance) {
        this.id = id;
        this.source = source;
        this.destination = destination;
        this.distance = distance;
        this.traffic = traffic;
    }

    public String getId() {
        return id;
    }
    public PlanetVO getDestination() {
        return destination;
    }

    public PlanetVO getSource() {
        return source;
    }
    public int getDistance() {
        return distance;
    }
    public int getTraffic() {
        return traffic;
    }
    @Override
    public String toString() {
        return source + " " + destination;
    }


}