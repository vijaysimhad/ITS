package com.intuit.its.utility;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.SocketTimeoutException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.ca.digital.manager.ErrorCodePageMappingManager;
import com.ca.digital.service.vo.TaskDetailsVO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.intuit.its.constants.DigitalConstants;
import com.intuit.its.error.ErrorMessage;


@Component("commonUtility")
public class CommonUtility {

	private static final Logger logger = Logger.getLogger(CommonUtility.class);
	
	
	static RestTemplate restTemplate;
	
	@Autowired
	@Qualifier(value="interceptingRestTemplate")
	public void setRestTemplate(RestTemplate restTemplate){
		CommonUtility.restTemplate = restTemplate;
	}
	
	

	static ObjectMapper jsonObj = new ObjectMapper();
	
	/**
	 * 
	 * @param value
	 * @return boolean
	 */
	public static boolean isStringEmpty(String value){
		return StringUtils.isEmpty(value);
	}
	
	/**
	 * 
	 * @param value
	 * @return boolean
	 */
	public static boolean isStringNotEmpty(String value){
		return !StringUtils.isEmpty(value);
	}
	
	/**
	 * 
	 * @param value
	 * @return boolean
	 */
	public static boolean isObjectEmpty(Object value){
		return StringUtils.isEmpty(value);
	}
	
	/**
	 * 
	 * @param value
	 * @return boolean
	 */
	public static boolean isObjectNotEmpty(Object value){
		return !StringUtils.isEmpty(value);
	}

	/**
	 * 
	 * @param value
	 * @return boolean
	 */
	public static boolean isObjectAndStringNotNull(Object value){
		if(isObjectNotEmpty(value) && isStringNotEmpty(value.toString())){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * 
	 * @param errorMessage
	 * @param errorCode
	 * @param errorDescription
	 * @param serviceName
	 * @return ErrorMessage
	 */
	public static ErrorMessage setErrorCodeAndMessage(ErrorMessage errorMessage, String errorCode, String requestField, String serviceName){
		errorMessage = new ErrorMessage(); 
		errorMessage.setErrorCode(errorCode);
		String errorDescription = propertyUtility.getErrorProperties().getProperty(errorCode);
		if(isObjectNotEmpty(errorDescription)){
			if(errorDescription.contains("?")){
				errorDescription = errorDescription.replace("?", requestField);
			}
			errorMessage.setErrorDescription(errorDescription);	
		}else
			errorMessage.setErrorDescription(requestField);		
		errorMessage.setServiceName(serviceName);
		
		return errorMessage;
	}


	/**
	 * 
	 * @param errorMessage
	 * @param errorCode
	 * @param errorDescription
	 * @param serviceName
	 * @return ErrorMessage
	 */
	public static ErrorMessage setRuntimeErrorCodeAndMessage(ErrorMessage errorMessage, String errorCode, String errorDescription, String serviceName){
		errorMessage = new ErrorMessage(); 
		errorMessage.setErrorCode(errorCode);
		errorMessage.setErrorDescription(errorDescription);	
		errorMessage.setServiceName(serviceName);
		
		return errorMessage;
	}

	/**
	 * 
	 * @param errorMessage
	 * @param errorCode
	 * @param serviceName
	 * @return ErrorMessage
	 */
	public static List<ErrorMessage> setErrorCodeAndMessage(List<ErrorMessage> errorList, ErrorMessage errorMessage, List<String> errorCode, List<String> fieldNames, String serviceName){
		String errorDescription = null;
		String code = null;
		errorMessage = new ErrorMessage(); 
		int placeHolderCount = 0;
		Iterator<String> itrERCD = errorCode.iterator();
		Iterator<String> itrFINM = fieldNames.iterator();
		while(itrERCD.hasNext() && itrFINM.hasNext()) {
		    // put your logic here
			code = itrERCD.next();
			errorDescription = itrFINM.next();
			if(isObjectNotEmpty(code)){
				placeHolderCount++;
				errorMessage.setErrorCode(code);
				errorDescription = String.format(propertyUtility.getErrorProperties().getProperty(code), errorDescription);
			}else if(isObjectEmpty(code)){
				int placeHolderFieldsCount=0;
				StringBuilder builder = new StringBuilder();
				for(String fields:fieldNames){
					if(placeHolderFieldsCount > placeHolderCount){
						builder.append(fields);
						placeHolderFieldsCount++;
					}					
				}
				errorDescription = String.format(errorDescription, builder);
			}
		}
		errorMessage.setServiceName(serviceName);
		
		return errorList;
	}
	
	/**
	 * 
	 * @param propKey
	 * @return
	 */
	public static String getQuickTrialCountryCodes(String propKey){
		String propValue = DigitalConstants.EMPTY;
		if(isObjectNotEmpty(propKey)){
			propKey = propKey.replaceAll("\\s+","");
			if(isObjectNotEmpty(propertyUtility)){
				propValue = propertyUtility.getQuickTrialCountryProperties().getProperty(propKey);
				if(isObjectNotEmpty(propValue)){
					return propValue;
				}
			}	
		}
		return propValue;
	}

	
	/**
	 * 
	 * @param propValue
	 * @return
	 */
	public static String getQuickTrialCountryNamesFromCodes(String propValue){
		String propKey = DigitalConstants.EMPTY;
		if(isObjectNotEmpty(propValue)){
			if(isObjectNotEmpty(propertyUtility)){
				Set<Entry<Object, Object>> keys = propertyUtility.getQuickTrialCountryProperties().entrySet();
		        for(Entry<Object, Object> k:keys){
		        	propKey = (CommonUtility.isObjectNotEmpty(k) && propValue.equalsIgnoreCase((String) k.getValue()))? getQuickTrialTwoCharCountryNamesForHarness((String) k.getValue()): DigitalConstants.EMPTY;
		            if(CommonUtility.isObjectNotEmpty(propValue)){
		            	break;
		            }
		            //System.out.println(k.getKey().toString()+": "+k.getValue().toString());
		        }
			}	
		}
		return propKey;
	}

	/**
	 * 
	 * @param propKey
	 * @return
	 */
	public static String getQuickTrialTwoCharCountryNamesForHarness(String propKey){
		String propValue = DigitalConstants.EMPTY;
		if(isObjectNotEmpty(propKey)){
			if(isObjectNotEmpty(propertyUtility)){
				propValue = propertyUtility.getQuickTrialCountryPropertiesForHarness().getProperty(propKey);
				if(isObjectNotEmpty(propValue)){
					return propValue;
				}
			}	
		}
		return propValue;
	}

	
	/**
	 * 
	 * @param propKey
	 * @return
	 */
	public static String getQuickTrialTwoCharCountryCodes(String propKey){
		String propValue = DigitalConstants.EMPTY;
		if(isObjectNotEmpty(propKey)){
			if(isObjectNotEmpty(propertyUtility)){
				propValue = propertyUtility.getQuickTrialTwoCharCountryProperties().getProperty(propKey);
				if(isObjectNotEmpty(propValue)){
					return propValue;
				}
			}	
		}
		return propValue;
	}
	
	/**
	 * 
	 * @param propKey
	 * @return
	 */
	public static String getQuickTrialCommonProperties(String propKey){
		String propValue = DigitalConstants.EMPTY;		
		if(isObjectNotEmpty(propertyUtility)){
			propValue = propertyUtility.getQuickTrialProperties().getProperty(propKey);
			if(isObjectNotEmpty(propValue)){
				return propValue;
			}
		}
		return propValue;
	}

	/**
	 * 
	 * @param propKey
	 * @return
	 */
	public static String getQuickTrialCommonProperties(String propKey, String defaultValue){
		String propValue = DigitalConstants.EMPTY;		
		if(isObjectNotEmpty(propertyUtility)){
			propValue = propertyUtility.getQuickTrialProperties().getProperty(propKey, defaultValue);
			if(isObjectNotEmpty(propValue)){
				return propValue;
			}
		}
		return propValue;
	}

	/**
	 * 
	 * @param taskDetailsListMap
	 * @return
	 */
	public static boolean isMapEmpty(Map<Integer, List<TaskDetailsVO>> taskDetailsListMap) {
		if(taskDetailsListMap!=null && taskDetailsListMap.size()>0){
			return false;
		}else{
			return true;
		}
		
	}
	
	/**
	 * 
	 * @param list
	 * @return
	 */
	public static boolean isListEmpty(List<Object> list) {
		if(list!=null && list.size()>0){
			return false;
		}else{
			return true;
		}
		
	}

	
	/**
	 * 
	 * @param countryName
	 * @return
	 * @throws IOException
	 */
	public static String getPropValues(String countryName) throws IOException {
		String result = "";
		InputStream inputStream = null;
		String countryCode = "";
		try {
			Properties prop = new Properties();
			String propFileName = "/config/countryNamesAndCode.properties";
			inputStream = CommonUtility.class.getClassLoader().getResourceAsStream(propFileName);
			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
			}
 			// get the property value and print it out
			countryCode = prop.getProperty(countryName);
 
			result = "Country Code = " + countryCode + " :::: " + "CountryName = "  + countryName;
			//System.out.println(result + "\nProgram Ran on " + " by user=" + countryName);
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
			inputStream.close();
		}
		return countryCode;
	}

	/**
	 * 
	 * @return
	 */
	public static String getCurrentTimeStamp() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());

		return timestamp.toString();
	}
	
	/**
	 * 
	 * @param reqResMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<ErrorMessage> getErrorList(Map<String, Object> reqResMap){
		List<ErrorMessage> errorList = null;
		if(isObjectNotEmpty(reqResMap.get(DigitalConstants.ERRORMESSAGE))){
			errorList=(List<ErrorMessage>) reqResMap.get(DigitalConstants.ERRORMESSAGE);
		}else{
			errorList = new ArrayList<ErrorMessage>();
		}
		
		return errorList;
	}
	
	/**
	 * 
	 * @param reqResMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<LinkedHashMap<String,Object>> getErrorMessage(Map<String, Object> reqResMap){
		List<LinkedHashMap<String,Object>> errorListOfLHMap = null;
		if(isObjectNotEmpty(reqResMap.get(DigitalConstants.ERRORMESSAGE))){
			errorListOfLHMap=(List<LinkedHashMap<String,Object>>) reqResMap.get(DigitalConstants.ERRORMESSAGE);
		}else{
			errorListOfLHMap = new ArrayList<LinkedHashMap<String,Object>>();
		}
		return errorListOfLHMap;
	}
	
	/**
	 * 
	 * @param reqResMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Object getErrorMessageMap(Map<String, Object> reqResMap){
		List<LinkedHashMap<String,Object>> errorListOfLHMap = null;
		if(isObjectNotEmpty(reqResMap.get(DigitalConstants.ERRORMESSAGE))){
			errorListOfLHMap=(List<LinkedHashMap<String,Object>>) reqResMap.get(DigitalConstants.ERRORMESSAGE);
		}else{
			errorListOfLHMap = new ArrayList<LinkedHashMap<String,Object>>();
		}
		return errorListOfLHMap;
	}

	/**
	 * 
	 * @param reqResMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static boolean checkForErrorList(Map<String, Object> reqResMap){
		List<ErrorMessage> errorList = (List<ErrorMessage>) reqResMap.get(DigitalConstants.ERRORMESSAGE);
		if(isObjectNotEmpty(errorList) && errorList.size() > 0){
			return true;
		}
		
		return false;
	}

	/**
	 * 
	 * @param headerMaps
	 * @param url
	 * @param errorList
	 * @param errorMessage
	 * @return
	 */
	public static String getRestCallServiceData(Map<String, Object> headerMaps, String url, List<ErrorMessage> errorList, ErrorMessage errorMessage) {
		// Form the service URL by appending all the above
		HttpEntity<String> entity;
		ResponseEntity<String> response = null;
		try {
			//If required please set the headers as per the requirement
			/*response = restTemplate.getForObject(url, String.class);*/
			HttpHeaders headers = prepareHttpHeader(headerMaps);
			entity = new HttpEntity<>(headers);
			response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
		} catch (ResourceAccessException e) {
			logger.info("There was timeout exception raised while SAAS Call ::: " + e.getMessage());
			errorList.add((ErrorMessage) CommonUtility.setErrorCodeAndMessage(errorMessage, DigitalConstants.QT_4008, e.getMessage(), "MarketoHelper"));
		} catch (HttpStatusCodeException exception) {
			int statusCode = exception.getStatusCode().value();
			logger.info("There was timeout exception raised while SAAS Call ::: " + exception.getMessage());
			errorList.add((ErrorMessage) CommonUtility.setErrorCodeAndMessage(errorMessage, DigitalConstants.QT_4008, exception.getMessage(), "MarketoHelper"));
		}

		return response.getBody();
	}

	/**
	 * 
	 * @param headerMaps
	 * @param url
	 * @param obj
	 * @param serviceName
	 * @param string 
	 * @param errorList
	 * @param errorMessage
	 * @return
	 */
	public static Object httpGetRestCallServiceData(Map<String, Object> headerMaps, String url, Object obj, String serviceName, MediaType mediaType, List<ErrorMessage> errorList, ErrorMessage errorMessage) {
		// Form the service URL by appending all the above
		HttpEntity<String> entity;
		ResponseEntity<String> responseString = null;
		ResponseEntity<Map> responseMap = null;
		try {
			//If required please set the headers as per the requirement
			/*response = restTemplate.getForObject(url, String.class);*/
			
			HttpHeaders headers = (headerMaps != null) ? prepareHttpHeader(headerMaps) : new HttpHeaders();
			headers.setContentType(mediaType);
			entity = new HttpEntity<>(headers);
			if(obj instanceof String){
				responseString = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);	
				return responseString.getBody();
			}else if(obj instanceof Map){
				responseMap = restTemplate.exchange(url, HttpMethod.GET, entity, Map.class);	
				return responseMap.getBody();
			}				
		} catch (ResourceAccessException e) {
			logger.info("There was timeout exception raised while SAAS Call ::: " + e.getMessage());
			errorList.add((ErrorMessage) CommonUtility.setErrorCodeAndMessage(errorMessage, DigitalConstants.QT_4008, e.getMessage(), serviceName));
		} catch (HttpStatusCodeException exception) {
			int statusCode = exception.getStatusCode().value();
			logger.info("There was timeout exception raised while SAAS Call ::: " + exception.getMessage());
			errorList.add((ErrorMessage) CommonUtility.setErrorCodeAndMessage(errorMessage, DigitalConstants.QT_4008, exception.getMessage(), serviceName));
		}

		return null;
	}
	
	/**
	 * 
	 * @param reqRespMap
	 * @param headerMaps
	 * @param url
	 * @param obj
	 * @param serviceName
	 * @param httpMethod
	 * @param mediaType
	 * @param errorList
	 * @param errorMessage
	 * @return
	 */
	public static Object httpGetOrPostRestCallServiceData(Map<String, Object> reqRespMap, Map<String, Object> headerMaps, String url, Object obj, String serviceName, HttpMethod httpMethod, MediaType mediaType, List<ErrorMessage> errorList, ErrorMessage errorMessage) {
		// Form the service URL by appending all the above
		String req = DigitalConstants.EMPTY;
		jsonObj = new ObjectMapper();
		HttpEntity<?> entity = null;
		ResponseEntity<String> responseString = null;
		ResponseEntity<Map> responseMap = null;
		try {
			//If required please set the headers as per the requirement
			HttpHeaders headers = (headerMaps != null) ? prepareHttpHeader(headerMaps) : new HttpHeaders();
			headers.setContentType(mediaType);
			if("GET".equalsIgnoreCase(httpMethod.toString())){
				entity = new HttpEntity<>(headers);	
			}else{				
				if(isObjectNotEmpty(reqRespMap)){
					req = jsonObj.writeValueAsString(reqRespMap).toString();			
				}
				entity = (obj instanceof String) ? new HttpEntity<String>(req, headers) : new HttpEntity<Map>(reqRespMap, headers);
			}
			logger.info("::::::::POST REQ:::::::::" + req +" :::: HEADER REQUEST :::: "+headers.toString()+" :::: Entity REQUEST :::: "+entity.toString());
			if(obj instanceof String){
				responseString = restTemplate.exchange(url, httpMethod, entity, String.class);	
				return responseString.getBody();
			}else if(obj instanceof Map){
				responseMap = restTemplate.exchange(url, httpMethod, entity, Map.class);	
				return responseMap.getBody();
			}
		} catch (ResourceAccessException e) {
			logger.info("There was timeout exception raised while SAAS Call ::: " + e.getMessage());
			errorList.add((ErrorMessage) CommonUtility.setErrorCodeAndMessage(errorMessage, DigitalConstants.QT_4008, e.getMessage(), serviceName));
		} catch (HttpStatusCodeException exception) {
			int statusCode = exception.getStatusCode().value();
			logger.info("There was HTTP error while SAAS Call ::: " + exception.getMessage());
			errorList.add((ErrorMessage) CommonUtility.setErrorCodeAndMessage(errorMessage, DigitalConstants.QT_4008, exception.getMessage(), serviceName));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("There was JSON Parsing Error while SAAS Call ::: " + e.getMessage());
			errorList.add((ErrorMessage) CommonUtility.setErrorCodeAndMessage(errorMessage, DigitalConstants.QT_4008, e.getMessage(), serviceName));
		}

		return null;
	}
	public static void initiateAsynchronousRestServiceWithMediaType(Map<String, Object> responseMap, Map<String, Object> headerMaps, AsyncRestTemplate template, String url, String serviceName, MediaType mediaType){
		HttpEntity<Map<String, Object>> requestEntity = null;
		HttpHeaders headers = (headerMaps != null) ? prepareHttpHeader(headerMaps) : new HttpHeaders();
		headers.setContentType(mediaType);
		
		requestEntity = new HttpEntity<Map<String,Object>>(responseMap, headers);
		
		template.postForEntity(url, requestEntity, Object.class);
	}
	/**
	 * 
	 * @param responseMap
	 * @param template
	 * @param url
	 */
	@SuppressWarnings("unused")
	public static void initiateAsynchronousRestService(Map<String, Object> responseMap, AsyncRestTemplate template, String url){
		HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<Map<String,Object>>(responseMap);
		template.postForEntity(url, requestEntity, Object.class);
	}
	
	private static HttpHeaders prepareHttpHeader(Map<String, Object> headerMaps) {
		HttpHeaders header = new HttpHeaders();
		header.set(DigitalConstants.TRIAL_TRANSACTION_ID, headerMaps.get(DigitalConstants.TRIAL_TRANSACTION_ID) == null ? com.ca.digital.utility.StringUtils.BLANK : headerMaps.get(DigitalConstants.TRIAL_TRANSACTION_ID).toString());
		header.set(DigitalConstants.TRIAL_ACTION_ID, headerMaps.get(DigitalConstants.TRIAL_ACTION_ID) == null ? com.ca.digital.utility.StringUtils.BLANK : headerMaps.get(DigitalConstants.TRIAL_ACTION_ID).toString());
		return header;
	}

	/**
	 * 
	 * @param obj
	 * @param url
	 * @param contentType
	 * @param authentication
	 * @param requestType
	 * @return
	 */
	public static String postRestCallServiceData(Map<String, Object> obj, String url, HttpHeaders header) {
		// TODO Auto-generated method stub
		/*restTemplate = new RestTemplate();*/
		jsonObj = new ObjectMapper();
		HttpEntity<String> entity = null;
		String response = DigitalConstants.EMPTY;
		String req = DigitalConstants.EMPTY;
		try {
			if(isObjectEmpty(header)){
				// set headers
				header = new HttpHeaders();
			}
			if(isObjectNotEmpty(obj)){
				req = jsonObj.writeValueAsString(obj).toString();			
			}
			entity = new HttpEntity<String>(req, header);
			logger.info("::::::::POST REQ:::::::::" + req +" :::: HEADER REQUEST :::: "+header.toString()+" :::: Entity REQUEST :::: "+entity.toString());			
			response = restTemplate.postForObject(url, entity, String.class);
			
		} catch (ResourceAccessException e) {
			logger.info("There was timeout exception raised while POST Call ::: " + e.getMessage());
		} catch (HttpStatusCodeException exception) {
			int statusCode = exception.getStatusCode().value();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response;
	}


	/**
	 * 
	 * @param obj
	 * @param url
	 * @param contentType
	 * @param authentication
	 * @param requestType
	 * @return
	 */
	public static String postRestCallServiceURI(Map<String, Object> obj, String url, HttpHeaders header, Map<String, String> urlStringValues) {
		// TODO Auto-generated method stub
		//restTemplate = new RestTemplate();
		jsonObj = new ObjectMapper();
		HttpEntity<String> entity = null;
		String response = DigitalConstants.EMPTY;
		String req = DigitalConstants.EMPTY;
		ResponseEntity<String> responseEntity = null;
		try {
			if(isObjectEmpty(header)){
				// set headers
				header = new HttpHeaders();
			}
			if(isObjectNotEmpty(obj)){
				req = jsonObj.writeValueAsString(obj).toString();			
			}
			entity = new HttpEntity<String>(req, header);
			logger.info("::::::::POST REQ:::::::::" + req +" :::: HEADER REQUEST :::: "+header.toString()+" :::: Entity REQUEST :::: "+entity.toString());			
			//response = restTemplate.postForObject(url, entity, String.class);


			responseEntity = restTemplate.exchange(url, org.springframework.http.HttpMethod.POST, entity, String.class, urlStringValues);
			//responseEntity.getBody()
			
		} catch (ResourceAccessException e) {
			logger.info("There was timeout exception raised while POST Call ::: " + e.getMessage());
		} catch (HttpStatusCodeException exception) {
			int statusCode = exception.getStatusCode().value();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return responseEntity.getBody().toString();
	}

	/**
	 * 
	 * @param obj
	 * @param url
	 * @param contentType
	 * @param authentication
	 * @param requestType
	 * @return
	 */
	public static String postRestCallServiceForFormData(MultiValueMap<String, String> obj, String url, HttpHeaders header) {
		// TODO Auto-generated method stub
		//restTemplate = new RestTemplate();
		jsonObj = new ObjectMapper();
		HttpEntity<?> entity = null;
		String response = DigitalConstants.EMPTY;
		String req = DigitalConstants.EMPTY;
		try {
			if(isObjectNotEmpty(obj)){
				if(isObjectEmpty(header)){
					// set headers
					header = new HttpHeaders();
				}
				entity = new HttpEntity<>(obj, header);
				logger.info("::::::::POST REQ:::::::::" + req +" :::: HEADER REQUEST :::: "+header.toString()+" :::: Entity REQUEST :::: "+entity.toString());
				response = restTemplate.postForObject(url, entity, String.class);				
			}
			
		} catch (ResourceAccessException e) {
			logger.info("There was timeout exception raised while POST Call ::: " + e.getMessage());
		} catch (HttpStatusCodeException exception) {
			int statusCode = exception.getStatusCode().value();
		} 

		return response;
	}

	/**
	 * 
	 * @param obj
	 * @param serviceName 
	 * @param errorMessage 
	 * @param errorList 
	 * @param headerMap 
	 * @return
	 * @throws SocketTimeoutException
	 */
	public static String postProvisioningData(Map<String, Object> obj, List<ErrorMessage> errorList, ErrorMessage errorMessage, String serviceName, Map<String, Object> headerMap) throws SocketTimeoutException {
		// TODO Auto-generated method stub
		String url = CommonUtility.getQuickTrialCommonProperties(DigitalConstants.PROVISIONIN_URL);
		String authorization = CommonUtility.getQuickTrialCommonProperties(DigitalConstants.BASIC_AUTHENTICATION);
		jsonObj = new ObjectMapper();
		HttpEntity<String> entity;
		String response = DigitalConstants.EMPTY;
		try {
			// set headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			//headers.add("Authorization", "Basic cXRhZG1pbjpDQWRlbW8xMjMh");
			headers.add("Authorization", authorization);
			
			// require trialTransactionID in header for handling param configuration @see PayloadLogger
			// IDM - headers.set(DigitalConstants.TRIAL_TRANSACTION_ID, headerMap.get(DigitalConstants.TRIAL_TRANSACTION_ID).toString());
			Iterator<Entry<String, Object>> headerMapIterator = headerMap.entrySet().iterator();
			while(headerMapIterator.hasNext()){
				Entry<String, Object> entry = headerMapIterator.next();
				headers.set(entry.getKey(), entry.getValue().toString());
			}

		//	obj.put("payloadConfigComponentName", "SAASPROVISIONING");
			String jsonReq = jsonObj.writeValueAsString(obj).toString();
			logger.info("Rest Request for "+serviceName +" ::: "+jsonReq);
			entity = new HttpEntity<String>(jsonReq,headers);
			response = restTemplate.postForObject(url, entity, String.class);
		}catch(ResourceAccessException e){ 
			logger.info("There was timeout exception raised while "+serviceName +" ::: "+e.getMessage());
			errorList.add((ErrorMessage)CommonUtility.setErrorCodeAndMessage(errorMessage, DigitalConstants.QT_4008, e.getMessage(), serviceName));
		}catch (HttpStatusCodeException exception) {
			int statusCode = exception.getStatusCode().value();
		}catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response;
	}

	/**
	 * 
	 * @param jsonString
	 * @return
	 */
	public static Map<String, Object> getJSONStringToMap(String jsonString){
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			// convert JSON string to Map
			map = jsonObj.readValue(jsonString, new TypeReference<Map<String, Object>>(){});
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	

		return map;
	}
	


	public static Object getMarketoIdValueFromJSONMap(String jsonString, String jsonKey){
		Map<String, Object> map = getJSONStringToMap(jsonString);
		String value = DigitalConstants.EMPTY;
		boolean flag = false;
		for(Map.Entry<String, Object> params: map.entrySet()){
			if("result".equalsIgnoreCase(params.getKey())){
				List<LinkedHashMap<String,Object>> list = (List<LinkedHashMap<String,Object>>) params.getValue();
				if(!CollectionUtils.isEmpty(list)){
					Object id =null;
					for(LinkedHashMap<String,Object> mapLinked: list){
						id = mapLinked.get("id");
						if(null!=id){
							value = String.valueOf(id);
							break;
						}
						//((LinkedHashMap)mapLinked);						
					}
					//value=list.get(0);
				}else{
					return "0";
				}
			}
			else if("error".equalsIgnoreCase(params.getKey())){
				List<?> list = (List<?>) params.getValue();
				if(isObjectNotEmpty(list) && list.size() > 0){
					value=list.get(0).toString();
					return value;
				}else{
					return "Error While Generating the Lead";
				}
				
			}
			  
		  }
			return value;
	}
	
	
	/**
	 * 
	 * @return
	 */
	public static ClientHttpRequestFactory getClientHttpRequestFactory() {
	    int timeout = 3000;
	    HttpComponentsClientHttpRequestFactory clientHttpRequestFactory =
	      new HttpComponentsClientHttpRequestFactory();
	    clientHttpRequestFactory.setConnectTimeout(timeout);
	    return clientHttpRequestFactory;
	}
	
	/**
	 * 
	 * @return
	 */
	@SuppressWarnings("unused")
	public static RestTemplate customRestTemplate(long timeout){
		
		if(isObjectNotEmpty(timeout)){
			logger.info(restTemplate.getRequestFactory());
			// commenting below code as we are setting timeout using properties file. 
			// because of interceptor, below getRequestFactory gives InterceptingClientHttpRequestFactory object instead of SimpleClientHttpRequestFactory
			//((SimpleClientHttpRequestFactory)restTemplate.getRequestFactory()).setReadTimeout(55000);
		}

        return restTemplate;
    }
	
	/**
	 * 
	 * @param restTemplate
	 * @param timeout
	 */
	public static void setTimeout(RestTemplate restTemplate, int timeout) {
        //Explicitly setting ClientHttpRequestFactory instance to     
        //SimpleClientHttpRequestFactory instance to leverage 
        //set*Timeout methods
        restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
        SimpleClientHttpRequestFactory rf = (SimpleClientHttpRequestFactory) restTemplate
                .getRequestFactory();
        rf.setReadTimeout(timeout);
        rf.setConnectTimeout(timeout);
    }
	
	
	/**
	 * 
	 * @return
	 */
	public static Map<String, Object> mockProvisioningResponse(){
		Map<String, Object> responseMap= new HashMap<String, Object>();
		Map<String, Object> finalResponseMap= new HashMap<String, Object>();
		responseMap.put("@xmlns:usm-core", "http://ns.ca.com/2009/07/usm-core");
		responseMap.put("@xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
		responseMap.put("@xsi:type", "usm-core:EntityID");
		responseMap.put("usm-core:MdrElementID", "Start_110394");
		responseMap.put("statuscode", "1000");
		responseMap.put("tenantid", "99999");
		finalResponseMap.put("usm-core:EntityID", responseMap);
		
		return finalResponseMap;
	}
	
	public static <K, V> Map<K, V> getLastRequestMap(Map<? extends K, ? extends V> left, Map<? extends K, ? extends V> right) {
        Map<K, V> finalMap = new HashMap<>();  
        if(CommonUtility.isObjectNotEmpty(left)){        	
        	if(CommonUtility.isObjectNotEmpty(right)){
        		for(Entry<? extends K, ? extends V> leftMap:left.entrySet()){
        			if(right.containsKey(leftMap.getKey())){
        				finalMap.put(leftMap.getKey(), right.get(leftMap.getKey()));
        			}else{
        				finalMap.put(leftMap.getKey(), leftMap.getValue());
        			}
        		}
        	}else{
        		finalMap = (Map<K, V>) left;
        	}        	
        }else{
        	finalMap = (Map<K, V>) right;
        }
        return finalMap;
    }
	
	/**
	 * 
	 * @param obj
	 * @param keyName
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Integer getIntValueFromMap(Object obj, String keyName){
		Integer value = null;
		if(CommonUtility.isObjectNotEmpty(obj)){
			Map<String, Object> reqResMap = (Map<String, Object>) obj;
			if(CommonUtility.isObjectNotEmpty(reqResMap.get(keyName))){
				Object  mapValue =reqResMap.get(keyName); 
				if( mapValue instanceof Integer){
					value=((Integer)mapValue);		
				}else{
					value=(Integer.parseInt(mapValue.toString()));
				}
			}
		}else{
			value=0;
		}
		
		return value;
	}
	
	/**
	 * 
	 * @param obj
	 * @param keyName
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static String getStringValueFromMap(Object obj, String keyName){
		String value = null;
		if(CommonUtility.isObjectNotEmpty(obj)){
			Map<String, Object> reqResMap = (Map<String, Object>) obj;
			if(CommonUtility.isObjectNotEmpty(reqResMap.get(keyName))){
				Object  mapValue =reqResMap.get(keyName); 
				if( mapValue instanceof String){
					value=(String) mapValue;		
				}else{
					value=DigitalConstants.EMPTY;
				}
			}
		}else{
			value=DigitalConstants.EMPTY;
		}
		return value;
	}
	
	/**
	 * 
	 * @param obj
	 * @param keyName
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> getUniqueMapFromRequestMap(Map<String, Object> responseMap, List<ErrorMessage> respErrorList, List<ErrorMessage> respCheckErrorList){
		Map<String, Object> finalMap = new HashMap<String, Object>();
		List<ErrorMessage> errorList=null;
		ErrorMessage errorMessage = null;
		LinkedHashMap<String , Object> tempMap = null;
		int count =0;
		List<Object> obj =  (List<Object>) responseMap.get(DigitalConstants.ERRORMESSAGE);
		if (respErrorList.size() == respCheckErrorList.size() && CommonUtility.isObjectNotEmpty(respErrorList) && CommonUtility.isObjectNotEmpty(respCheckErrorList)) {
			errorList = new ArrayList<ErrorMessage>();
			 for (Object map1 : respErrorList) {
				 count++;
				 LinkedHashMap<String , Object> map = (LinkedHashMap<String, Object>) map1;
				 
				 if(CommonUtility.isObjectEmpty(tempMap)){
					 tempMap = map;
					 errorList.add(CommonUtility.setErrorCodeAndMessage(errorMessage, map.get(DigitalConstants.ERROR_CODE).toString(), map.get(DigitalConstants.ERROR_DESCRIPTION).toString(), map.get("serviceName").toString()));
				 }else{
					 if(!(map.get(DigitalConstants.ERROR_DESCRIPTION).equals(tempMap.get(DigitalConstants.ERROR_DESCRIPTION)))){
						 if(map.get(DigitalConstants.ERROR_CODE).equals(tempMap.get(DigitalConstants.ERROR_CODE))){
							 errorList.add(CommonUtility.setErrorCodeAndMessage(errorMessage, map.get(DigitalConstants.ERROR_CODE).toString(), map.get(DigitalConstants.ERROR_DESCRIPTION).toString(), map.get("serviceName").toString()));
						 }	 
					 }
					 tempMap = new LinkedHashMap<String, Object>();
				 }
			 }
			 responseMap.put(DigitalConstants.ERRORMESSAGE, errorList);
	    }
		
		return responseMap;
	}

	/**
	 * 
	 * @param responseMap
	 * @param key
	 * @param indetifier
	 * @return
	 */
	public static String getValueFromJSONTree(Map<String, Object> responseMap, String key, String indetifier){
		String value = DigitalConstants.EMPTY;
		jsonObj = new ObjectMapper();
		
		try {
			String jsonReq = jsonObj.writeValueAsString(responseMap).toString();
			JsonNode root = jsonObj.readTree(jsonReq);
			// Get Name
			JsonNode nameNode = root.path(indetifier);
			if (nameNode.isMissingNode()) {
				// if "name" node is missing
			} else {
				value = nameNode.path(key).asText();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return value;	
	}
	
	/**
	 * 
	 * @param responseMap
	 * @param key
	 * @param indetifier
	 * @return
	 */
	public static Object getJSONValueFromJSONTree(Map<String, Object> responseMap, String key, String indentifier){
		String value = DigitalConstants.EMPTY;
		List<Map<String, Object>> list = null;
		jsonObj = new ObjectMapper();
		Map<String,Object> entitlementMap = null;
		try {
			String jsonReq = jsonObj.writeValueAsString(responseMap).toString();
			JsonNode root = jsonObj.readTree(jsonReq);
			Iterator<Map.Entry<String, JsonNode>> fields = root.fields();
			 while (fields.hasNext()) {
			    Map.Entry<String, JsonNode> entry = fields.next();
			    System.out.println(entry.getKey() + ":" + entry.getValue());
			    // Only Key from root level check
			    if(key.equalsIgnoreCase(entry.getKey()) && isObjectEmpty(indentifier)){
			    	value = entry.getValue().toString();
			    	return value;
			    }else{
			    	if(entry.getValue().isArray()){
			    		if(indentifier.equalsIgnoreCase(entry.getKey()) && isObjectEmpty(key) ){
							// Get Name
							JsonNode nameNode = root.path(indentifier);
							if (nameNode.isMissingNode()) {
								// if "name" node is missing
							} else {
								//list = new ArrayList<Map<String,Object>>();
								list = ((nameNode.isArray())) ? jsonObj.readValue(nameNode.toString(), new TypeReference<List<Map>>(){}): list;
								return list;
							}					    			
			    		}else{
							for (final JsonNode objNode : entry.getValue()) {
								entitlementMap = new HashMap<String,Object>();
						        System.out.println(objNode);
						        value = objNode.path(key).asText();
						        System.out.println(value);
						        entitlementMap = jsonObj.readValue(objNode.toString(), new TypeReference<Map<String, Object>>(){});
						        if(entitlementMap.containsKey(key)){
						        	value = entitlementMap.get(key).toString();
						        	return value;
						        }
						    }					    			
			    		}					    		
					}
			    }
			 }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return value;	
	}


	public static Integer getValueAsInt(String property) {
		return Integer.parseInt(property);
	}
	
	/**
	 * 
	 * @param sec
	 * @return
	 */
	public static Timestamp getSecondsDiffForDBQuery(Integer sec) {
		
		long retryDate = System.currentTimeMillis();
        //int sec = 2;
        Timestamp original = new Timestamp(retryDate);
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(original.getTime());
        cal.add(Calendar.SECOND, sec);
        Timestamp later = new Timestamp(cal.getTime().getTime());

        System.out.println(original);
        System.out.println(later);
        
		return later;
	}
	
	/**
	 * 
	 * @param url
	 * @param responseMap 
	 */
	public static Object initiateRestURLService(Map<String, Object> responseMap, String url) {
				 
		 Map<String, Object> requestMap = new LinkedHashMap<String, Object>();
		// set headers
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<Map<String,Object>>(requestMap, headers);
		
		return restTemplate.postForEntity(url, requestEntity, Object.class).getBody();
	} 
		 



	/**
	 * 
	 * @param reqResMap
	 * @param key
	 */
	public static void removeMapKeys(Map<String, Object> reqResMap, String key){
		
		if(reqResMap.containsKey(key)){
			reqResMap.remove(key);
		}
	}

	/**
	 * 
	 * @param name
	 * @param value
	 * @return
	 */
	public static Map<String, Object> setArgumentMap(String name, Object value){
		Map<String, Object> argsMap= new HashMap<String, Object>();
		argsMap.put(DigitalConstants.NAME, name);
		argsMap.put(DigitalConstants.VALUE, value);
		
		return argsMap;		
	}
	
	public static Date setEntitlementEndDate(String endDate, String noOfDays){
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
	    Date date = null;
		try {
			//date = format.parse("2012-06-25 15:02:22.948");
			date = format.parse(endDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    Calendar calendar = new GregorianCalendar();
	    calendar.setTime(date);

	    if((new Date()).after(calendar.getTime())){
	    	calendar.setTime(new Date());
		}
	    System.out.println("-------------"+calendar.getTime().toString());
	    calendar.add(Calendar.DATE, Integer.parseInt(noOfDays));
		System.out.println("-------------"+calendar.getTime().toString());
	    return calendar.getTime();
	  }
	
	/**
	 * 
	 * @param date
	 * @return
	 */
	public static Date setEntitlementDateFormat(String endDate){
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
	    Date date = null;
		try {
			//date = format.parse("2012-06-25 15:02:22.948");
			date = format.parse(endDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    Calendar calendar = new GregorianCalendar();
	    calendar.setTime(date);

	    if((new Date()).after(calendar.getTime())){
	    	calendar.setTime(new Date());
		}
	    return calendar.getTime();
	  }

	
	public Object searchNestedMap(Map<String, Object> requestMap, String paramName) {
		Object paramValue = null;
		Set<String> keys = requestMap.keySet();
		if(keys.contains(paramName)){
			return requestMap.get(paramName);
		}
		for(String key : keys){
			if(requestMap.get(key) instanceof Map ){
				paramValue = searchNestedMap((Map<String, Object>)requestMap.get(key), paramName);
				if(paramValue != null){
					return paramValue;
				}
			}
			if(requestMap.get(key) instanceof List){
				List<Map<String, Object>>  list = (List<Map<String, Object>>) requestMap.get(key);
				for(Map<String, Object> map : list){
					paramValue = searchNestedMap(map, paramName);
					if(paramValue != null){
						return paramValue;
					}
				}
			}
		}
		return null;
	}
	
	public void putValueInNestedMap(Map<String, Object> requestMap, String paramName, Object value) {
		Object paramValue = null;
		Set<String> keys = requestMap.keySet();
		if(keys.contains(paramName)){
			 requestMap.put(paramName, value);
		}
		else{
		for(String key : keys){
			if(requestMap.get(key) instanceof Map ){
				putValueInNestedMap((Map<String, Object>)requestMap.get(key), paramName, value);
				/*if(paramValue != null){
					System.out.println("2");
					requestMap.put(paramName, value);
				}*/
			}
			if(requestMap.get(key) instanceof List){
				List<Map<String, Object>>  list = (List<Map<String, Object>>) requestMap.get(key);
				for(Map<String, Object> map : list){
				 putValueInNestedMap(map, paramName, value);
					/*if(paramValue != null){
						System.out.println("3");
						requestMap.put(paramName, value);
					}*/
				}
			}
		}}
	}

	public String getValueAsString(Map<String, Object> map, String key, String defaultValue){
		Object valueAsObject = map.get(key);
		if(valueAsObject == null)
			return defaultValue;
		return valueAsObject.toString();
	}
	
	public Integer getValueAsInteger(Map<String, Object> map, String key, Integer defaultValue){
		Object valueAsObject = map.get(key);
		if(valueAsObject == null)
			return defaultValue;
		return Integer.parseInt(valueAsObject.toString());
	}

	/**
	 * 
	 * @param reqRespMap
	 * @param errorCodePageMappingManager
	 */
	@SuppressWarnings("unused")
	public static void setErrorPagaNamesForErrorCode(Map<String, Object> reqRespMap, ErrorCodePageMappingManager errorCodePageMappingManager) {
		if(CommonUtility.isObjectNotEmpty(reqRespMap) && reqRespMap.containsKey(DigitalConstants.ERRORMESSAGE)){
			List<LinkedHashMap<String,Object>> errorListOfLHMap = null;
			ErrorMessage errorMessage = null;
			try {				
				if(reqRespMap.get(DigitalConstants.ERRORMESSAGE) instanceof List<?>){
					if(!CollectionUtils.isEmpty((Collection<?>) reqRespMap.get(DigitalConstants.ERRORMESSAGE))){
						if(((List<?>)reqRespMap.get(DigitalConstants.ERRORMESSAGE)).size() > 0){
							errorMessage = (ErrorMessage) ((List<?>)reqRespMap.get(DigitalConstants.ERRORMESSAGE)).get(0);
							reqRespMap = consolidateErrorList(reqRespMap, errorMessage, errorCodePageMappingManager);
						}
					}
					//consolidateErrorList(errorListOfLHMap, errorCodePageMappingManager);				
				}else if(reqRespMap.get(DigitalConstants.ERRORMESSAGE) instanceof ErrorMessage){
					errorMessage = (ErrorMessage) reqRespMap.get(DigitalConstants.ERRORMESSAGE);
					reqRespMap = consolidateErrorList(reqRespMap, errorMessage, errorCodePageMappingManager);
				}
				//quickTrialHelper.sendInternalEmail(errorListOfLHMap, trailServiceHandlerResponse);
			} catch (Exception e) {
				e.printStackTrace();
			}
			logger.info("In setErrorPagaNamesForErrorCode()  for setting the redirect Page for the single Error Code  ::: " + reqRespMap.toString());
		}
	}

	
	
	/**
	 * 
	 * @param errorMessage2
	 */
	public static Map<String, Object> consolidateErrorList(Map<String, Object> reqRespMap, ErrorMessage errorMessage2, ErrorCodePageMappingManager errorCodePageMappingManager){
		// Prepare map for consolidate list		
		boolean checkIfError = (CommonUtility.isObjectNotEmpty(errorMessage2)) ? true : false ;
		if(checkIfError){
			Map<String, Object> errorCodeMap = jsonObj.convertValue(errorMessage2, Map.class);
			//List<LinkedHashMap<String, Object>> errorListResultant = setPageNameForErrorCodes(errorCodeMap, errorCodePageMappingManager);
			reqRespMap.put(DigitalConstants.ERRORMESSAGE, setPageNameForErrorCodes(errorCodeMap, errorCodePageMappingManager));
			logger.info("In consolidateErrorList()  for setting the redirect Page for the single Error Code  ::: " + reqRespMap.toString());
		}
		
		return reqRespMap;
	}

	
	/**
	 * 
	 * @param errorCodeMap
	 * @param errorCodePageMappingManager
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<LinkedHashMap<String, Object>> setPageNameForErrorCodes(Map<String, Object> errorCodeMap, ErrorCodePageMappingManager errorCodePageMappingManager) {
		List<LinkedHashMap<String, Object>> finalErrorMapList = new ArrayList<LinkedHashMap<String, Object>>();
		
		List<String> errorCodeList = new ArrayList<String>();
		errorCodeList.add(errorCodeMap.get(DigitalConstants.ERROR_CODE).toString());
		// Prepare map for consolidate list
		Map<String, Object> map = (Map<String, Object>) errorCodePageMappingManager.findErrorCodesList(errorCodeList);
		if(!CollectionUtils.isEmpty(map)){			
			errorCodeMap.put(DigitalConstants.REDIRECT_PAGE, map.get(errorCodeMap.get(DigitalConstants.ERROR_CODE)));
			finalErrorMapList.add((LinkedHashMap<String, Object>) errorCodeMap);
			logger.info("In setPageNameForErrorCodes()  for setting the redirect Page for the single Error Code  ::: " + finalErrorMapList.toString());
		}
		
		return finalErrorMapList;
	}

	/**
	 * 
	 * @param date
	 * @param dateFormat
	 * @param returnObject
	 * @return
	 */
	public static Object getDateFormat(String date, String dateFormat, Object returnObject) {
		
		DateFormat outputFormat = new SimpleDateFormat(dateFormat, Locale.ENGLISH);
	    outputFormat.setTimeZone(TimeZone.getDefault());
	    try {
			Date formattedDate = outputFormat.parse(date);		    		    		   
		    if(returnObject instanceof String){
		    	String output = outputFormat.format(date);
		    	System.out.println("output : " +output);	
		    	return output;
		    }else if(returnObject instanceof Date){
		    	return formattedDate;
		    }
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    
		
		return null;

	}

	public static Object getDateFormat(Date date, String dateFormat) {
		
		DateFormat outputFormat = new SimpleDateFormat(dateFormat, Locale.ENGLISH);
	    outputFormat.setTimeZone(TimeZone.getDefault());
    	String output = outputFormat.format(date);
    	System.out.println("output : " +output);	
    	return output;
	}

}
