package com.intuit.its.service;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.intuit.its.constants.DigitalConstants;
import com.intuit.its.manager.PlanetManager;
import com.intuit.its.service.vo.PlanetVO;
import com.intuit.its.utility.CommonUtility;

@RestController
@Service("planetService")
@Scope("prototype")
public class PlanetService implements ServiceAction{

	private static final Logger logger = Logger.getLogger(PlanetService.class);
	
	@Autowired
	@Qualifier(value = "planetManager")
	PlanetManager planetManager;
	
	String urlString;
	
	public void init() {
		// TODO Auto-generated method stub
		String URL = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest().getRequestURI();
		urlString = "";
		if(CommonUtility.isStringNotEmpty(URL)){
			urlString = URL.substring(URL.lastIndexOf('/') +1);
		}
		logger.info("---------------URL is --------------"+URL);
		
	}
	
	@RequestMapping(value = "/*", method = RequestMethod.POST)
	@ResponseBody
	public Object execute(@RequestBody Map<String, Object> reqResMap) {
		this.init();
		logger.info(CommonUtility.getCurrentTimeStamp() +": ---- PlanetService Execute Method Started -------");
		if(DigitalConstants.UPDATE_PLANET.equals(urlString)){
//			reqResMap = updatePlanet(reqResMap);
		}	
		else if(DigitalConstants.CREATE_PLANET.equals(urlString)){
			reqResMap = createPlanet(reqResMap);
		}
		else if(DigitalConstants.SEARCH_PLANETS_SHORT_DISTANCE.equals(urlString)){
			reqResMap = searchPathByDistance(reqResMap);
		}
		else if(DigitalConstants.SEARCH_PLANETS_SHORT_TRAFFIC.equals(urlString)){
			reqResMap = searchPathByTraffic(reqResMap);
		}
		else if(DigitalConstants.GET_ALL_PLANETS.equals(urlString)){
			reqResMap = getAllPlanets(reqResMap);
		}
		
		logger.info(CommonUtility.getCurrentTimeStamp() +": ---- PlanetService Execute Method Ended -------");
		return reqResMap;
	}
		
	private Map<String, Object> searchPathByTraffic(Map<String, Object> reqResMap) {
		String originPlanetId=reqResMap.get("originPlanetId").toString();
		String destinationPlanetId=reqResMap.get("destinationPlanetId").toString();
		reqResMap.get("destinationPlanetId").toString();
		List<PlanetVO> list = planetManager.getAllPlanets();
		List<PlanetVO> path=planetManager.searchPathByTraffic(originPlanetId,destinationPlanetId);
		return null;
	}

	private Map<String, Object> searchPathByDistance(Map<String, Object> reqResMap) {
		String originPlanetId=reqResMap.get("originPlanetId").toString();
		String destinationPlanetId=reqResMap.get("destinationPlanetId").toString();
		List<PlanetVO> list = planetManager.getAllPlanets();
		List<PlanetVO> path=planetManager.searchPathByDistance(originPlanetId,destinationPlanetId);
			
		return null;
	}

	public Map<String, Object> createPlanet(@RequestBody Map<String, Object> reqResMap) {
		Integer planetId; 
		planetId = (Integer)planetManager.createPlanet(reqResMap.get("planetName").toString());
		reqResMap.put("planetId", planetId);
		return reqResMap;
	}

	public Map<String, Object> getAllPlanets(@RequestBody Map<String, Object> reqResMap) {
		Integer sequenceGroup,serial;
			try {
				logger.info(CommonUtility.getCurrentTimeStamp() +": ---- Get All Planets Service is called -------");
				List<PlanetVO> list = planetManager.getAllPlanets();
				reqResMap.put("Planets", list);
			} catch (Exception e) {
				logger.info(CommonUtility.getCurrentTimeStamp() +": ---- Exception Raised during Get All Planets Service -------");
				e.printStackTrace();
			}
		return reqResMap;
	}

	public void getResponse() {
		

	}

}
