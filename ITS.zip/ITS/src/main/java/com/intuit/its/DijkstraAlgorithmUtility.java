package com.intuit.its;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.intuit.its.service.vo.EdgeVO;
import com.intuit.its.service.vo.GraphVO;
import com.intuit.its.service.vo.PlanetVO;

public class DijkstraAlgorithmUtility {
	private final List<PlanetVO> planets;
    private final List<EdgeVO> edges;
    private Set<PlanetVO> settledNodes;
    private Set<PlanetVO> unSettledNodes;
    private Map<PlanetVO, PlanetVO> predecessors;
    private Map<PlanetVO, Integer> distance;
    private Map<PlanetVO, Integer> traffic;

    public DijkstraAlgorithmUtility(GraphVO graph) {
        // create a copy of the array so that we can operate on this array
        this.planets = new ArrayList<PlanetVO>(graph.getPlanets());
        this.edges = new ArrayList<EdgeVO>(graph.getEdges());
    }

    public void execute(PlanetVO source) {
        settledNodes = new HashSet<PlanetVO>();
        unSettledNodes = new HashSet<PlanetVO>();
        distance = new HashMap<PlanetVO, Integer>();
        predecessors = new HashMap<PlanetVO, PlanetVO>();
        distance.put(source, 0);
        traffic.put(source, 0);
        unSettledNodes.add(source);
        while (unSettledNodes.size() > 0) {
        	PlanetVO node = getMinimum(unSettledNodes);
            settledNodes.add(node);
            unSettledNodes.remove(node);
            findMinimalDistance(node);
            findMinimalTraffic(node);
        }
    }

    private void findMinimalDistance(PlanetVO node) {
        List<PlanetVO> adjacentNodes = getNeighbors(node);
        for (PlanetVO target : adjacentNodes) {
            if (getDistance(target) > getDistance(node)
                    + getDistance(node, target)) {
                distance.put(target, getDistance(node)
                        + getDistance(node, target));
                predecessors.put(target, node);
//                unSettledNodes.add(target);
            }
        }
    }
    private void findMinimalTraffic(PlanetVO node) {
        List<PlanetVO> adjacentNodes = getNeighbors(node);
        for (PlanetVO target : adjacentNodes) {
            if (getTraffic(target) > getTraffic(node)
                    + getTraffic(node, target)) {
                traffic.put(target, getTraffic(node)
                        + getTraffic(node, target));
                predecessors.put(target, node);
//                unSettledNodes.add(target);
            }
        }

    }
    private int getTraffic(PlanetVO node, PlanetVO target) {
        for (EdgeVO edge : edges) {
            if (edge.getSource().equals(node)
                    && edge.getDestination().equals(target)) {
                return edge.getTraffic();
            }
        }
        throw new RuntimeException("Should not happen");
    }
    private int getDistance(PlanetVO node, PlanetVO target) {
        for (EdgeVO edge : edges) {
            if (edge.getSource().equals(node)
                    && edge.getDestination().equals(target)) {
                return edge.getDistance();
            }
        }
        throw new RuntimeException("Should not happen");
    }

    private List<PlanetVO> getNeighbors(PlanetVO node) {
        List<PlanetVO> neighbors = new ArrayList<PlanetVO>();
        for (EdgeVO edge : edges) {
            if (edge.getSource().equals(node)
                    && !isSettled(edge.getDestination())) {
                neighbors.add(edge.getDestination());
            }
        }
        return neighbors;
    }

    private PlanetVO getMinimum(Set<PlanetVO> planets) {
    	PlanetVO minimum = null;
        for (PlanetVO planet : planets) {
            if (minimum == null) {
                minimum = planet;
            } else {
                if (getDistance(planet) < getDistance(minimum)) {
                    minimum = planet;
                }
            }
        }
        return minimum;
    }

    private boolean isSettled(PlanetVO planet) {
        return settledNodes.contains(planet);
    }

    private int getDistance(PlanetVO destination) {
        Integer d = distance.get(destination);
        if (d == null) {
            return Integer.MAX_VALUE;
        } else {
            return d;
        }
    }
    private int getTraffic(PlanetVO destination) {
        Integer d = traffic.get(destination);
        if (d == null) {
            return Integer.MAX_VALUE;
        } else {
            return d;
        }
    }
    /*
     * This method returns the path from the source to the selected target and
     * NULL if no path exists
     */
    public LinkedList<PlanetVO> getPath(PlanetVO target) {
        LinkedList<PlanetVO> path = new LinkedList<PlanetVO>();
        PlanetVO step = target;
        // check if a path exists
        if (predecessors.get(step) == null) {
            return null;
        }
        path.add(step);
        while (predecessors.get(step) != null) {
            step = predecessors.get(step);
            path.add(step);
        }
        // Put it into the correct order
        Collections.reverse(path);
        return path;
    }
    public LinkedList<PlanetVO> getPath(String source,String target,String type) {
        LinkedList<PlanetVO> path = new LinkedList<PlanetVO>();
        
        
//        PlanetVO step = target;
//        // check if a path exists
//        if (predecessors.get(step) == null) {
//            return null;
//        }
//        path.add(step);
//        while (predecessors.get(step) != null) {
//            step = predecessors.get(step);
//            path.add(step);
//        }
//        // Put it into the correct order
//        Collections.reverse(path);
        return path;
    }
    

	}