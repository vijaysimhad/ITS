package com.intuit.its.service;

import java.util.Map;

import org.springframework.context.annotation.Scope;


@Scope("prototype")
public interface ServiceAction {
	
	public void init() ;
	
	public void getResponse();
	
	public Object execute(Map<String, Object> reqResDC);
	
	
}
