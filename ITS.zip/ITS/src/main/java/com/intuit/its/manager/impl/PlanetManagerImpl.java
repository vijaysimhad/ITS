package com.intuit.its.manager.impl;

import java.util.List;

import com.intuit.its.manager.PlanetManager;
import com.intuit.its.service.vo.PlanetVO;

public class PlanetManagerImpl implements PlanetManager{

	@Override
	public Integer createPlanet(PlanetVO obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updatePlanet(PlanetVO obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public PlanetVO findPlanet(PlanetVO obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PlanetVO findPlanetByID(PlanetVO obj, String string) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PlanetVO> getAllPlanets() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PlanetVO> searchPathByDistance(String originPlanetId, String destinationPlanetId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PlanetVO> searchPathByTraffic(String originPlanetId, String destinationPlanetId) {
		// TODO Auto-generated method stub
		return null;
	}

}
