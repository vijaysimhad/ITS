/**
 * 
 */
package com.intuit.its.dao;

import java.util.List;

import org.hibernate.SessionFactory;

/**
 * @author Vijayasimha Devulapalli
 * @param <T>
 *
 */
public interface BaseDAO<BaseDTO> {

	public Object create(final BaseDTO entity,SessionFactory sessionFactory) throws Exception;

	public List<BaseDTO> getAll(String className,SessionFactory sessionFactory) throws Exception;

	public void update(final BaseDTO entity,SessionFactory sessionFactory) throws Exception;

	public void delete(final BaseDTO entity,SessionFactory sessionFactory) throws Exception;

	public void deleteById(final Long entityId,SessionFactory sessionFactory) throws Exception;
	
	public Object createEnt(final BaseDTO entity,SessionFactory sessionFactory) throws Exception;

	//public Integer saveOrupdate(final BaseDTO entity,SessionFactory sessionFactory) throws Exception;
}
