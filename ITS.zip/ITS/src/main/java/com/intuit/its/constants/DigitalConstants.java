/**
 * 
 */
package com.intuit.its.constants;

/**
 * @author Vijayasimha Devulapalli
 *
 */
public class DigitalConstants {
	public static final String PLANETNAME = "planetName";
	public static final String PLANETNODE = "planetNode";
	public static final String PLANETID="planetId";
	public static final String TRAFFIC="traffic";
	public static final String DISTANCE="distance";

	public static final String ERRORMESSAGE = "ErrorMessage";
	public static final String SERVICE_NAME="serviceName";
	public static final String ERROR_DESCRIPTION = "errorDescription";
	public static final String SUCCESS="Success";
	public static final String ERROR="Error";
	public static final String ZERO="0";
	public static final String EMPTY="";
	public static final String ACTIVE="Active";
	public static final String DISABLED="Disabled";
	public static final String ENABLED="Enabled";
	
	
	// Service Calls
	public static final String SEARCH_PLANETS_SHORT_DISTANCE = "searchPlanetsShortDistance";
	public static final String SEARCH_PLANETS_SHORT_TRAFFIC = "searchPlanetsShortTraffic";
	public static final String CREATE_PLANET = "createPlanet";
	public static final String UPDATE_PLANET = "updatePlanet";
	public static final String GET_ALL_PLANETS = "getAllPlanets";
	public static final String CREATE_TRANSACTION = "createTransaction";
	public static final String PLANET_SERVICE = "planetService";
	
	
	public static final String FAILURE = "FAILURE";
	public static final String COMPLETE = "COMPLETE";
	public static final String DUPLICATE_USER_REQUEST = "DUPLICATE REQUEST";
	public static final String INPROGRESS = "INPROGRESS";
	public static final String STATUS_FLAG = "Status";
	public static final String ENVIRONMENT = "Environment";
	public static final String INITIATE = "INITIATE";
	
	public static final String APPCONTEXT = "appContext";
	
	public static final String FORM_URL_ENCODED = "application/x-www-form-urlencoded";

	public static final String REQUEST_PAYLOAD = "requestPayload";
	
	public static final String SERVICE_DETAIL = "serviceDetail";
	
	public static final String ACTION="action";
	
	public static final String AVAILABLE="Available";
	
}
