package com.intuit.its.error;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component("errorMessage")
public class ErrorMessage implements Serializable{

	private static final long serialVersionUID = 4933306902692257710L;
	
	private String errorCode;
	private String errorDescription;
	private String serviceName;
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
	
}
