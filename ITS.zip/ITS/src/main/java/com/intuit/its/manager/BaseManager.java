package com.intuit.its.manager;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class BaseManager {

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	@Qualifier(value="entsessionFactory")
	private SessionFactory entsessionFactory;

	@Autowired
	@Qualifier("hadbSessionFactory")
	private SessionFactory hadbSessionFactory;

	@Autowired
	@Qualifier("eaiSessionFactory")
	private SessionFactory eaidbSessionFactory;
	
	public SessionFactory getEntsessionFactory() {
		return entsessionFactory;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	/**
	 * @return the hadbSessionFactory
	 */
	public SessionFactory getHadbSessionFactory() {
		return hadbSessionFactory;
	}
	
	public SessionFactory getEaidbSessionFactory() {
		return eaidbSessionFactory;
	}
}
