package com.intuit.its.dto;

import java.io.Serializable;

import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
@Table(name="Edge")
public class EdgeDTO implements Serializable, BaseDTO{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GenericGenerator(name="edgeinc" , strategy="increment")
	@GeneratedValue(generator="edgeinc")
	@Column(name="EdgeID")
    private Integer edgeId;
	
	@ManyToOne
    @JoinColumn(name="sourceId")
    private PlanetDTO source;

    @ManyToOne
    @JoinColumn(name="destinationId")
    private PlanetDTO destination;

    private final int distance;
    private final int traffic;
	public Integer getEdgeId() {
		return edgeId;
	}
	public void setEdgeId(Integer edgeId) {
		this.edgeId = edgeId;
	}
	public PlanetDTO getSource() {
		return source;
	}
	public void setSource(PlanetDTO source) {
		this.source = source;
	}
	public PlanetDTO getDestination() {
		return destination;
	}
	public void setDestination(PlanetDTO destination) {
		this.destination = destination;
	}
	public int getDistance() {
		return distance;
	}
	public int getTraffic() {
		return traffic;
	}
    
    
}
