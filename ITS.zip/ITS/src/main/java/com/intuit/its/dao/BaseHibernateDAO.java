package com.intuit.its.dao;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.springframework.stereotype.Repository;

import com.ca.digital.constants.DigitalConstants;
import com.ca.digital.entity.ActionSequenceDTO;
import com.ca.digital.entity.CallbackConfigDTO;
import com.ca.digital.entity.DomainDTO;
import com.ca.digital.entity.DomainTrialDTO;
import com.ca.digital.entity.ERErPCodeMaterialIdDTO;
import com.ca.digital.entity.ProductOfferingTypesDTO;
import com.ca.digital.entity.ProductTrialConfigDTO;
import com.ca.digital.entity.SAASProvisioningParamsDTO;
import com.ca.digital.entity.SAASProvisioningResponseParamsDTO;
import com.ca.digital.entity.TrialCampaignConfigDTO;
import com.ca.digital.entity.TrialProvisioningConfigDTO;
import com.ca.digital.entity.TrialRequestDTO;

import jersey.repackaged.com.google.common.base.Preconditions;

@Repository
public class BaseHibernateDAO<BaseDTO extends Serializable> implements BaseDAO<BaseDTO> {
	
	private static final Logger logger = Logger.getLogger(BaseHibernateDAO.class);
	
	private Class<BaseDTO> daoClass;
	String basemgr=null;

	/**
	 * 
	 * @param clazzToSet
	 */
	public void setDAOClass(final Class<BaseDTO> clazzToSet) {
		this.daoClass = clazzToSet;
		
	}

	/**
	 * 
	 * @param id
	 * @param sessionFactory
	 * @return
	 */
	public BaseDTO getById(final Long id,SessionFactory sessionFactory) {
		//Preconditions.checkArgument(id != null);
		return (BaseDTO) sessionFactory.getCurrentSession().get(this.daoClass, id);
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<BaseDTO> getByName(final String queryString, final String queryColumnName, final String queryColumnvalue, SessionFactory sessionFactory) {
		logger.info("In Basehibernate ::: "+queryString + queryColumnName);
		Query query = sessionFactory.getCurrentSession().createQuery(queryString);
		query.setParameter(queryColumnName,queryColumnvalue );
		logger.info("In Basehibernate Query ::: "+query.toString());
		return (List<BaseDTO>) query.list();
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<BaseDTO> getById(final String queryString, final String queryColumnName, final Integer queryColumnvalue, SessionFactory sessionFactory) {
		
		Query query = sessionFactory.getCurrentSession().createQuery(queryString);
		query.setParameter(queryColumnName,queryColumnvalue );
		return (List<BaseDTO>) query.list();
	}
	/**
	 * 
	 */
	@SuppressWarnings("unchecked")
	public List<BaseDTO> getAll(String className,SessionFactory sessionFactory) {
		return sessionFactory.getCurrentSession().createQuery("from " + className).list();
	}

	public Object create(final BaseDTO entity,SessionFactory sessionFactory) throws HibernateException {
		//Preconditions.checkNotNull(entity);
		return (Integer) sessionFactory.getCurrentSession().save(entity);
		//return (Object) sessionFactory.getCurrentSession().merge(entity);
	}
	public Object createStringPrimaryKey(final BaseDTO entity,SessionFactory sessionFactory) throws HibernateException {
		return (String) sessionFactory.getCurrentSession().save(entity);
	}
	public Object createEnt(final BaseDTO entity,SessionFactory sessionFactory) throws HibernateException {
		//Preconditions.checkNotNull(entity);
		return  sessionFactory.getCurrentSession().save(entity);
		//return (Object) sessionFactory.getCurrentSession().merge(entity);
	}
	public void createOrUpdate(final BaseDTO entity,SessionFactory sessionFactory) throws HibernateException {
		//Preconditions.checkNotNull(entity);
		sessionFactory.getCurrentSession().saveOrUpdate(entity);
		//return (Object) sessionFactory.getCurrentSession().merge(entity);
	}

	public void update(final BaseDTO entity,SessionFactory sessionFactory) {
		//Preconditions.checkNotNull(entity);
		sessionFactory.getCurrentSession().update(entity);
	}
	
	public void delete(final BaseDTO entity,SessionFactory sessionFactory) {
		//Preconditions.checkNotNull(entity);
		sessionFactory.getCurrentSession().delete(entity);
	}
	
	public void deleteById(final Long entityId,SessionFactory sessionFactory) {
		final BaseDTO entity = this.getById(entityId,sessionFactory);
		Preconditions.checkState(entity != null);
		sessionFactory.getCurrentSession().delete(entity);
	}
	/**
	 * 
	 * @param qry
	 * @param domainDTO
	 * @param strTrialId
	 * @param sessionFactory
	 * @return
	 */
	public Long verifyDomainName(String qry,DomainDTO domainDTO,String strTrialId,SessionFactory sessionFactory) {
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("trialId",new Integer(strTrialId));
		query.setParameter("domainId",domainDTO.getDomainId());
		//query.setParameter("categoryId",domainDTO.getCategoryId());			
		Long count = (Long)query.uniqueResult();		
		return count;		
	}
	/**
	 * 
	 * @param qry
	 * @param domainDTO
	 * @param strTrialId
	 * @param sessionFactory
	 * @return
	 */
	
	public Long verifyDomainNameForAll(String qry,DomainDTO domainDTO,String strTrialId,SessionFactory sessionFactory) {
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("trialId",new Integer(strTrialId));
		//query.setParameter("domainId",domainDTO.getDomainId());
		query.setParameter("categoryId",domainDTO.getCategoryId());			
		Long count = (Long)query.uniqueResult();		
		return count;		
	}
	/**
	 * 
	 * @param qry
	 * @param domainName
	 * @param sessionFactory
	 * @return
	 */
	public DomainDTO getDomainDetails(String qry,String domainName,SessionFactory sessionFactory) {
		DomainDTO domainDTO = null;
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("domainName",domainName );
		for(Iterator it=query.iterate();it.hasNext();){
  		  domainDTO=(DomainDTO)it.next();        				   
		}
		return domainDTO;
		
	}

	/**
	 * 
	 * @param qry
	 * @param trialId
	 * @param sessionFactory
	 * @return
	 */
	public ProductTrialConfigDTO getTrialDetails(String qry,String trialId,SessionFactory sessionFactory) {
		ProductTrialConfigDTO productTrialConfigDTO = null;
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("trialID",new Integer(trialId) );
		for(Iterator it=query.iterate();it.hasNext();){
			productTrialConfigDTO=(ProductTrialConfigDTO)it.next();        				   
		}
		return productTrialConfigDTO;
		
	}
	
	/**
	 * 
	 * @param qry
	 * @param trialTransactionId
	 * @param sessionFactory
	 * @return
	 */
	public ProductTrialConfigDTO getTrialDetailsForTransaction(String qry,String trialTransactionId,SessionFactory sessionFactory) {
		ProductTrialConfigDTO productTrialConfigDTO = null;
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("trialTransactionId",new Integer(trialTransactionId) );
		for(Iterator it=query.iterate();it.hasNext();){
			productTrialConfigDTO=(ProductTrialConfigDTO)it.next();        				   
		}
		return productTrialConfigDTO;
		
	}
	/**
	 * 
	 * @param qry
	 * @param trialId
	 * @param sessionFactory
	 * @return
	 */
	public Object deleteTrialIdDomains(String qry,Integer trialId,SessionFactory sessionFactory) {
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("trialID",trialId);
		int res = query.executeUpdate();
		return new Integer(res);
	}
	
	public void deleteDomainTrialDetailsByDomainIds(String qry,List<Integer> domainIds,SessionFactory sessionFactory) {
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameterList("domainIDs",domainIds);
		int res = query.executeUpdate();
	}
		
	/**
	 * 
	 * @param entity
	 * @param alias
	 * @param sessionFactory
	 * @return
	 */
	public Criteria createCriteria( Class<BaseDTO> entity, String alias,SessionFactory sessionFactory ){
	    return sessionFactory.getCurrentSession().createCriteria( entity,alias );
	}
	
	/**
	 * Get the list of the rows based on the where conditions and returns List
	 * @param queryString
	 * @param queryValues
	 * @param sessionFactory
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<BaseDTO> getListOfEntityObjects(final String queryString, Map<String, Object> queryValues, SessionFactory sessionFactory) {
		
		Query query = sessionFactory.getCurrentSession().createQuery(queryString);
		//query.setParameter(queryColumnName,queryColumnvalue );
		if((null != queryValues && queryValues.size() > 0)){
			for(Map.Entry<String, Object> entry : queryValues.entrySet()){
				query.setParameter(entry.getKey(),entry.getValue());
			}
		}
		return (List<BaseDTO>) query.list();
	}

	/**
	 * Get the list of the rows based on the where conditions and returns List
	 * @param queryString
	 * @param queryValues
	 * @param offLimit
	 * @param maxResults 
	 * @param sessionFactory
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<BaseDTO> getListOfEntityObjects(final String queryString, Map<String, Object> queryValues, Integer offLimit, Integer maxResults, SessionFactory sessionFactory) {
		
		Query query = sessionFactory.getCurrentSession().createQuery(queryString);
		//query.setParameter(queryColumnName,queryColumnvalue );
		if((null != queryValues && queryValues.size() > 0)){
			for(Map.Entry<String, Object> entry : queryValues.entrySet()){
				query.setParameter(entry.getKey(),entry.getValue());
			}
		}
		if(null == maxResults)
			maxResults = 50;
		query = (null == offLimit) ? query.setFirstResult(0).setMaxResults(maxResults): query.setFirstResult(offLimit).setMaxResults(maxResults);
		//query.setMaxResults(offLimit);
		
		return (List<BaseDTO>) query.list();
	}
	/**
	 * 
	 * @param queryString
	 * @param queryValues
	 * @param sessionFactory
	 */
	@SuppressWarnings("unchecked")
	public void updateEntityObjects(final String queryString, Map<String, Object> queryValues, SessionFactory sessionFactory) {
		
		Query query = sessionFactory.getCurrentSession().createQuery(queryString);
		//query.setParameter(queryColumnName,queryColumnvalue );
		if((null != queryValues && queryValues.size() > 0)){
			for(Map.Entry<String, Object> entry : queryValues.entrySet()){
				query.setParameter(entry.getKey(),entry.getValue());
			}
		}
		int res = query.executeUpdate();
	}
	
	/**
	 * 
	 * @param query
	 * @param sessionFactory
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<BaseDTO> getListUsingCreateQuery(String query,SessionFactory sessionFactory) {
		//Preconditions.checkArgument(id != null);
		Query queryResult = sessionFactory.getCurrentSession().createQuery(query);
		return (List<BaseDTO>) queryResult.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<BaseDTO> getListUsingTrialId(String qry,String trialId,SessionFactory sessionFactory) {
		//Preconditions.checkArgument(id != null);
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("trialId",new Integer(trialId));
		return (List<BaseDTO>) query.list();
	}
	
	public void updateDomainTrialDetails(String qry,DomainTrialDTO domainTrialDTO,SessionFactory sessionFactory) {
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("categoryId",domainTrialDTO.getCategoryId());
		query.setParameter("domainID",domainTrialDTO.getDomainID());		
		int res = query.executeUpdate();
		//return new Integer(res);
	}
	
	public ProductOfferingTypesDTO getOfferingTypeDetails(String qry,Integer offeringTypeID,SessionFactory sessionFactory) {
		ProductOfferingTypesDTO productOfferingTypesDTO = null;
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("offeringTypeID",offeringTypeID);
		for(Iterator it=query.iterate();it.hasNext();){
			productOfferingTypesDTO = (ProductOfferingTypesDTO)it.next();        				   
		}
		return productOfferingTypesDTO;		
	}
	
	public void updatedProvisioningDetails(String qry,TrialProvisioningConfigDTO trialProvisioningConfigDTO,SessionFactory sessionFactory) {
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("mdrElementID",trialProvisioningConfigDTO.getMdrElementID());
		query.setParameter("isInstantProvisioning",trialProvisioningConfigDTO.isInstantProvisioning());
		query.setParameter("onpremDownloadPath",trialProvisioningConfigDTO.getOnpremDownloadPath());
		query.setParameter("onpremFileName",trialProvisioningConfigDTO.getOnpremFileName());
		query.setParameter("onpremUrlValidity",trialProvisioningConfigDTO.getOnpremUrlValidity());
		query.setParameter("productTrialConfigDTO",trialProvisioningConfigDTO.getProductTrialConfigDTO());
		int res = query.executeUpdate();		
	}
	
	public void updatedProvisioningParams(String qry,SAASProvisioningParamsDTO sAASProvisioningParamDTO,SessionFactory sessionFactory) {
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("parameterName",sAASProvisioningParamDTO.getParameterName());
		query.setParameter("parameterValue",sAASProvisioningParamDTO.getParameterValue());
		query.setParameter("parameters",sAASProvisioningParamDTO.getParameters());
		query.setParameter("productTrialConfigDTO",sAASProvisioningParamDTO.getProductTrialConfigDTO());
		int res = query.executeUpdate();
	}
	
	public void updatedTrialRequest(String qry,TrialRequestDTO trialRequestDTO,SessionFactory sessionFactory) {
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("provisioningStatus",trialRequestDTO.getProvisioningStatus());
		query.setParameter("provisioningID",trialRequestDTO.getProvisioningID());
		query.setParameter("marketoLeadID",trialRequestDTO.getMarketoLeadID());
		int res = query.executeUpdate();
	}
	
	public TrialRequestDTO getgetTrialTransaction(String qry,String mdrelementid,SessionFactory sessionFactory) {
		TrialRequestDTO trialRequestDTO = null;
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("mdrelementid",mdrelementid);
		for(Iterator it=query.iterate();it.hasNext();){
			trialRequestDTO=(TrialRequestDTO)it.next();        				   
		}		
		return trialRequestDTO;		
	}
	
	public void updatedSassProvisioningResponseParams(String qry,SAASProvisioningResponseParamsDTO sAASProvisioningResponseParamsDTO,SessionFactory sessionFactory){
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("paramValue",sAASProvisioningResponseParamsDTO.getParamValue());
		query.setParameter("trialTransactionId",sAASProvisioningResponseParamsDTO.getTrialRequestDTO());
		query.setParameter("paramName",sAASProvisioningResponseParamsDTO.getParamName());
		int res = query.executeUpdate();		
	}	
	
	public void deletedSassProvisioningResponseParams(String qry,SAASProvisioningResponseParamsDTO sAASProvisioningResponseParamsDTO,SessionFactory sessionFactory){
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("trialTransactionID",sAASProvisioningResponseParamsDTO.getTrialRequestDTO().getTrialTransactionID());
		int res = query.executeUpdate();
	}
	
	public TrialRequestDTO getNoOfTrialsForEmailId(String qry,String userId,String trialId,SessionFactory sessionFactory) {
		TrialRequestDTO trialRequestDTO = null;
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("userId",new Integer(userId));
		query.setParameter("trialID",new Integer(trialId));			
		for(Iterator it=query.iterate();it.hasNext();){
			trialRequestDTO=(TrialRequestDTO)it.next();   				   
		}
		return trialRequestDTO;
	}
		
	public void updateTrialCompaigns(String qry,TrialCampaignConfigDTO trialCampaignConfigDTO,SessionFactory sessionFactory){
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("trialcampaignID",trialCampaignConfigDTO.getTrialcampaignID());
		query.setParameter("trialID",trialCampaignConfigDTO.getProductTrialConfigDTO().getTrialID());
		query.setParameter("campaignKey",trialCampaignConfigDTO.getMarketoCampaignDetailDTO().getCampaignKey());
		int res = query.executeUpdate();
	}
	
	public void updatedLeadToTrialRequest(String qry,Map<String, Object> reqResMap,SessionFactory sessionFactory) {
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("marketoLeadID",reqResMap.get(DigitalConstants.MARKETO_LEAD_ID).toString());
		query.setParameter("trialTransactionID",Integer.parseInt(reqResMap.get(DigitalConstants.TRIAL_TRANSACTION_ID).toString()));
		int res = query.executeUpdate();
	}
	
	public void deleteSequenceActions(String qry,ActionSequenceDTO actionSequenceDTO,SessionFactory sessionFactory){
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("sequenceGroup",actionSequenceDTO.getSequenceGroup());
		int res = query.executeUpdate();
	}
	
	public ProductTrialConfigDTO getTrialDetails(String qry,Integer trialID,SessionFactory sessionFactory) {
		ProductTrialConfigDTO productTrialConfigDTO = null;
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("trialID",trialID );
		for(Iterator it=query.iterate();it.hasNext();){
			productTrialConfigDTO=(ProductTrialConfigDTO)it.next();        				   
		}
		return productTrialConfigDTO;
		
	}
	
	public ERErPCodeMaterialIdDTO getErpcodeDetails(String qry,ERErPCodeMaterialIdDTO erErPCodeMaterialIdDTO,SessionFactory sessionFactory) {
		//ERErPCodeMaterialIdDTO erErPCodeMaterialIdDTO = null;
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("materialId",erErPCodeMaterialIdDTO.getMaterialId());
		for(Iterator it=query.iterate();it.hasNext();){
			erErPCodeMaterialIdDTO=(ERErPCodeMaterialIdDTO)it.next();        				   
		}
		return erErPCodeMaterialIdDTO;
		
	}
	
	/**
	 * 
	 * @param qry
	 * @param strTrialId
	 * @param sessionFactory
	 * @return
	 */
	public Long findPublicCategoryBlock(String qry,String strTrialId,SessionFactory sessionFactory) {
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("trialId",new Integer(strTrialId));
		Long count = (Long)query.uniqueResult();		
		return count;		
	}
	
	public void updateProvisioningStatus(String query,String trialTransactionId,SessionFactory sessionFactory){
		Query qry = sessionFactory.getCurrentSession().createQuery(query);
		qry.setParameter("trialTransactionID",new Integer(trialTransactionId));
		int res = qry.executeUpdate();
	}
	
	public TrialRequestDTO getActiveTrialTransaction(String qry,String email,String trialId,SessionFactory sessionFactory) {
		TrialRequestDTO trialRequestDTO = null;
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("email",email);
		query.setParameter("trialID",new Integer(trialId));			
		for(Iterator it=query.iterate();it.hasNext();){
			trialRequestDTO=(TrialRequestDTO)it.next();   				   
		}
		return trialRequestDTO;
	}
	
	public Object getTrialTransaction(String qry,String email,String trialId,SessionFactory sessionFactory) {
		Integer trialTransactionID = null;
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("email",email);
		query.setParameter("trialID",new Integer(trialId));			
		for(Iterator it=query.iterate();it.hasNext();){
			trialTransactionID=(Integer) it.next();			
		}
		return trialTransactionID;
	}
	
	public Object getTrialIdForIdentifier(String qry,String trialIdentifier,SessionFactory sessionFactory){
		ProductTrialConfigDTO productTrialConfigDTO = null;
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		query.setParameter("trialIdentifier",trialIdentifier);
		for(Iterator it=query.iterate();it.hasNext();){
			productTrialConfigDTO=(ProductTrialConfigDTO)it.next();        				   
		}
		return productTrialConfigDTO;		
	}
	
	public Object createCallbackTransaction(String qry,Map<String, Object> reqResMap,SessionFactory sessionFactory){
		//SystemServiceLookupDTO systemServiceLookupDTO = null;
		CallbackConfigDTO callbackConfigDTO = null;
		Query query = sessionFactory.getCurrentSession().createQuery(qry);
		//SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(qry);
		//query.setParameter("Domain",reqResMap.get(DigitalConstants.CALL_BACK).toString());
		query.setParameter("callbackkey",reqResMap.get(DigitalConstants.RALLY).toString());
		
		/*for(Map.Entry<String, Object> entry : reqResMap.entrySet()){
			query.setParameter(entry.getKey(),entry.getValue());
	}*/
		for(Iterator it=query.iterate();it.hasNext();){
			callbackConfigDTO=(CallbackConfigDTO)it.next();   				   
		}
	return callbackConfigDTO;
		//return (List<CallbackConfigDTO>) query.list();
	
	}
	
	public ProjectionList getProjectionList(List<String> propertiesList){
		ProjectionList projectionList = Projections.projectionList();
		for(String propertyName : propertiesList){
			projectionList.add(Projections.property(propertyName));
		}
		return projectionList;
	}
	
}
