package com.intuit.its;

public class Planet {

}
