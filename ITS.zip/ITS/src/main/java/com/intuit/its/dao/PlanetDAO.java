package com.intuit.its.dao;

import java.util.List;
import java.util.Map;

import org.hibernate.SessionFactory;

import com.intuit.its.dto.PlanetDTO;

/**
 * 
 * @author Vijayasimha Devuloapalli
 *
 */
public interface PlanetDAO {
	
	public Object createPlanet(PlanetDTO planetDTO,SessionFactory sessionFactory);
	
	public void updatePlanet(Map<String, Object> queryValuesMap,SessionFactory sessionFactory);
	
	public Object findPlanet(String planetId,SessionFactory sessionFactory);
	
	public List<PlanetDTO> getAllPlanets(SessionFactory sessionFactory);

}
