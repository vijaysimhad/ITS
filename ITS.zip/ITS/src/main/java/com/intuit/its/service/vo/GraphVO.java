package com.intuit.its.service.vo;

import java.util.List;

public class GraphVO {

    private final List<PlanetVO> planets;
    private final List<EdgeVO> edges;

    public GraphVO(List<PlanetVO> planets, List<EdgeVO> edges) {
        this.planets = planets;
        this.edges = edges;
    }

    public List<PlanetVO> getPlanets() {
        return planets;
    }

    public List<EdgeVO> getEdges() {
        return edges;
    }



}
