package com.intuit.its.dao.impl;

import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;

import com.intuit.its.dao.BaseHibernateDAO;
import com.intuit.its.dao.EdgeDAO;
import com.intuit.its.dto.EdgeDTO;
import com.intuit.its.utility.CommonUtility;

public class EdgeDAOImpl extends BaseHibernateDAO implements EdgeDAO{
	private static final Logger logger = Logger.getLogger(EdgeDAOImpl.class);
	
	@SuppressWarnings("unchecked")
	@PostConstruct
	public void setClassForDao(){
		setDAOClass(EdgeDAOImpl.class);
	}

	@Override
	public Object createEdge(EdgeDTO edgeDTO,SessionFactory sessionFactory) {
		// TODO Auto-generated method stub
		logger.info(CommonUtility.getCurrentTimeStamp()+" :::  In Edge DAO IMPL for createEdge ::: ");
		return create(edgeDTO,sessionFactory);
	}
	@Override
	public List<EdgeDTO> getAllPlanets(SessionFactory sessionFactory) {
		return getAll("EdgeDTO",sessionFactory);
	}
}
