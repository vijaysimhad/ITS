package com.intuit.its.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="Planet")
public class PlanetDTO implements Serializable, BaseDTO{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 25702173784258710L;

	@Id
	@GenericGenerator(name="planetinc" , strategy="increment")
	@GeneratedValue(generator="planetinc")
	@Column(name="PlanetID")
    private Integer planetId;
	
	@Column(name="PlanetName")
	private String planetName;
	
	@Column(name="PlanetNode")
	private String planetNode;
	
	@Column(name="Distance")
	private Integer distance;	
	
	@Column(name="Traffic")
	private Integer traffic;	
	
	
		
}
