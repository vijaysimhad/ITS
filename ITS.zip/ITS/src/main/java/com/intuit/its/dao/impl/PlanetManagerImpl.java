package  com.intuit.its.dao.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ca.digital.constants.DigitalConstants;
import com.ca.digital.dao.PlanetDAO;
import com.ca.digital.entity.PlanetDTO;
import com.ca.digital.manager.BaseManager;
import com.ca.digital.manager.PlanetManager;
import com.ca.digital.service.vo.PlanetVO;
import com.ca.digital.utility.CommonHelper;
import com.ca.digital.utility.CommonUtility;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Vijayasimha Devulapalli
 *
 */

@Component
@Qualifier("planetManager")
@Transactional
@Scope("prototype")
public class PlanetManagerImpl extends BaseManager implements PlanetManager{

	private static final Logger logger = Logger.getLogger(PlanetManagerImpl.class);
	
	@Autowired
	PlanetDAO planetDAO;
	
	@Autowired
	@Qualifier(value="commonHelper")
	CommonHelper commonHelper;
		
	/*
	 * (non-Javadoc)
	 * @see com.ca.digital.manager.PlanetManager#createPlanet(java.lang.Object)
	 */
	@SuppressWarnings("unchecked")
	public boolean updatePlanet(Object requestFO){
		boolean resplanetDTO = true;
		logger.info(CommonUtility.getCurrentTimeStamp()+" :::  In Manager for createPlanet ::: ");
		PlanetDTO planetDTO = (PlanetDTO)commonHelper.convertToPlanetDTO((Map<String, String>)requestFO);
		Map<String, Object> queryValuesMap = new HashMap<String, Object>();		
		//queryValuesMap.put(DigitalConstants.EMAIL, planetDTO.getEmail());		
		//queryValuesMap.put(DigitalConstants.ACTIVE.toLowerCase(), true);
		queryValuesMap.put(DigitalConstants.COMPANY_NAME, ((Map<String, String>) requestFO).get(DigitalConstants.COMPANY_NAME));
		queryValuesMap.put(DigitalConstants.COUNTRY, ((Map<String, String>) requestFO).get(DigitalConstants.COUNTRY));
		queryValuesMap.put(DigitalConstants.JOB_TITLE, ((Map<String, String>) requestFO).get(DigitalConstants.JOB_TITLE));
		queryValuesMap.put(DigitalConstants.JOB_GROUP, ((Map<String, String>) requestFO).get(DigitalConstants.JOB_GROUP));
		queryValuesMap.put(DigitalConstants.FIRST_NAME, ((Map<String, String>) requestFO).get(DigitalConstants.FIRST_NAME));
		queryValuesMap.put(DigitalConstants.LAST_NAME, ((Map<String, String>) requestFO).get(DigitalConstants.LAST_NAME));
		queryValuesMap.put(DigitalConstants.PHONE_NUMBER, ((Map<String, String>) requestFO).get(DigitalConstants.PHONE_NUMBER));
		queryValuesMap.put(DigitalConstants.REG_REGION, ((Map<String, String>) requestFO).get(DigitalConstants.REG_REGION));		
		queryValuesMap.put("updatedDate", new java.sql.Timestamp(new Date().getTime()));
		queryValuesMap.put(DigitalConstants.USER_ID, CommonUtility.getIntValueFromMap(requestFO, DigitalConstants.USER_ID));
		try{
			planetDAO.updatePlanet(queryValuesMap,getSessionFactory());	
			if(resplanetDTO){
				logger.info(CommonUtility.getCurrentTimeStamp()+" :::  Planet Details are updated ::: "+planetDTO.getUserId());
			}
		}catch(Exception e){
			e.printStackTrace();
			resplanetDTO = false;
		}
		
		return resplanetDTO;
	}

	@SuppressWarnings("unchecked")
	public Integer createPlanet(Object requestFO) {
		Integer resplanetDTO = null;
		logger.info(CommonUtility.getCurrentTimeStamp()+" :::  In Planet DAO IMPL for createPlanet ::: ");
		PlanetDTO planetDTO = (PlanetDTO)commonHelper.convertToPlanetDTO((Map<String, String>)requestFO);
		try{
			resplanetDTO = (Integer) planetDAO.createPlanet(planetDTO,getSessionFactory());	
			if(null != resplanetDTO){
				logger.info("Inserted record "+resplanetDTO);
			}
		}catch(Exception e){
			e.printStackTrace();
		}

		return resplanetDTO;
	}

	@SuppressWarnings("unchecked")
	public PlanetVO findPlanetByID(Object requestFO,  String userIdForAOP) {
		// TODO Auto-generated method stub
		List<PlanetDTO> resplanetDTO = null;
		Integer userId = Integer.parseInt(userIdForAOP);
		PlanetVO planetVO = null;
		logger.info(CommonUtility.getCurrentTimeStamp()+" :::  In Planet DAO IMPL for createPlanet ::: ");
		PlanetDTO planetDTO = (PlanetDTO)commonHelper.convertToPlanetDTO((Map<String, String>)requestFO);
		try{
			resplanetDTO = (List<PlanetDTO>) planetDAO.findPlanetForAOP(planetDTO, userId, getSessionFactory());	
			if(null != resplanetDTO && resplanetDTO.size() > 0){
				System.out.println("Planet record already exists in DB "+resplanetDTO);
				planetDTO = resplanetDTO.get(0);
				planetVO = new PlanetVO();
				planetVO = commonHelper.convertToPlanetVO(planetDTO,planetVO);
			}
		}catch(Exception e){
			e.printStackTrace();
		}

		return planetVO;
	}

	@SuppressWarnings("unchecked")
	public PlanetVO findPlanet(Object requestFO) {
		// TODO Auto-generated method stub
		logger.info(CommonUtility.getCurrentTimeStamp()+" :::  In Planet DAO IMPL for createPlanet ::: ");
		List<PlanetDTO> resplanetDTO = null;
		PlanetVO resplanetVO = null;
		ObjectMapper mapper = new ObjectMapper();
		PlanetDTO planetDTO = (PlanetDTO)commonHelper.convertToPlanetDTO((Map<String, String>)requestFO);
		
		Map<String, Object> createPlanetQueryValuesMap = new HashMap<String, Object>();
		
		createPlanetQueryValuesMap.put(DigitalConstants.EMAIL, planetDTO.getEmail());
		//createPlanetQueryValuesMap.put(DigitalConstants.COMPANY_NAME, planetDTO.getCompanyName());
		try{
			resplanetDTO = (List<PlanetDTO>) planetDAO.findUniqueEmailAndCompanyName(createPlanetQueryValuesMap,getSessionFactory());
			if(null != resplanetDTO && resplanetDTO.size() > 0){
				System.out.println("Planet record already exists in DB "+resplanetDTO);
				for(PlanetDTO dto: resplanetDTO){
					resplanetVO = mapper.convertValue(dto, PlanetVO.class);	
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return resplanetVO;
	}

	
	
}
