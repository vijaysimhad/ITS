package com.intuit.its.dao;

import java.util.List;

import com.intuit.its.dao.impl.SessionFactory;
import com.intuit.its.dto.EdgeDTO;

public interface EdgeDAO {
	public Object createEdge(EdgeDTO edgeDTO,SessionFactory sessionFactory);
	public List<EdgeDTO> getAllPlanets(SessionFactory sessionFactory);
}
