package com.intuit.its.manager;

import java.util.List;

import org.springframework.stereotype.Component;

import com.intuit.its.service.vo.PlanetVO;

@Component("planetManager")
public interface PlanetManager{
	
	public Integer createPlanet(PlanetVO obj);
	
	public boolean updatePlanet(PlanetVO obj);
	
	public PlanetVO findPlanet(PlanetVO obj);

	public PlanetVO findPlanetByID(PlanetVO obj, String string);
	
	public List<PlanetVO> getAllPlanets();

	public List<PlanetVO> searchPathByDistance(String originPlanetId, String destinationPlanetId);

	public List<PlanetVO> searchPathByTraffic(String originPlanetId, String destinationPlanetId);
	
}
