# shortest-route
Interstellar Transport System
