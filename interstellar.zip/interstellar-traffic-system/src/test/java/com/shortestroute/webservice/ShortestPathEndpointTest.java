package com.shortestroute.webservice;

import static com.shazam.shazamcrest.MatcherAssert.assertThat;
import static com.shazam.shazamcrest.matcher.Matchers.sameBeanAs;

import org.hibernate.validator.internal.engine.path.PathImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import com.intuit.interstellar.config.DataSourceConfig;
import com.intuit.interstellar.config.PersistenceConfig;
import com.intuit.interstellar.config.Resource;
import com.intuit.interstellar.data.processor.ExcelDataProcessor;
import com.intuit.interstellar.repository.EdgeRepository;
import com.intuit.interstellar.repository.TrafficInfoRepository;
import com.intuit.interstellar.repository.VertexRepository;
import com.intuit.interstellar.service.ImportDataService;
import com.intuit.interstellar.service.ShortestPathService;
import com.intuit.interstellar.webservice.ShortestRouteEndpoint;
import com.intuit.interstellar.webservice.ShortestRouteRepository;
import com.intuit.interstellar.webservice.config.WebServiceConfiguration;
import com.intuit.interstellar.webservice.schema.FindShortestPathToRequest;
import com.intuit.interstellar.webservice.schema.FindShortestPathToResponse;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PathImpl.class, ShortestPathService.class, ExcelDataProcessor.class,
        Resource.class, DataSourceConfig.class, PersistenceConfig.class, WebServiceConfiguration.class,
        ShortestRouteEndpoint.class, ShortestRouteRepository.class, ImportDataService.class, EdgeRepository.class,
        VertexRepository.class,
        TrafficInfoRepository.class},
        loader = AnnotationConfigContextLoader.class)
public class ShortestPathEndpointTest {

    @Autowired
    private ShortestRouteEndpoint shortestPathEndpoint;

    @Test
    public void verifyThatShortestPathSOAPEndPointIsCorrect() throws Exception {
        // Set Up Fixture
        FindShortestPathToRequest shortestPathRequest = new FindShortestPathToRequest();
        shortestPathRequest.setName("Moon");

        StringBuilder path = new StringBuilder();
        path.append("Earth (A) Moon (B) ");

        FindShortestPathToResponse expectedResponse = new FindShortestPathToResponse();
        expectedResponse.setPath(path.toString());
        expectedResponse.setDistanceTravelled("0.44 (Light Years)");

        //Test
        FindShortestPathToResponse actualResponse = shortestPathEndpoint.getShortestPath(shortestPathRequest);

        // Verify
        assertThat(actualResponse, sameBeanAs(expectedResponse));
        assertThat(actualResponse.getPath(), sameBeanAs(path));
    }

}
